import sqlite3
import os.path
import sys
from PyQt5 import QtCore, QtGui, QtWidgets

sys.path.append('../')


BASE_DIR = os.path.dirname(os.path.abspath(__file__))
db_path = "../../Database/InventoryDatabase.db"
conn=sqlite3.connect(db_path)

class Delete2MainDB:
    def Delete2DB(itemName,itemNo):

       ## itemName= db
        ##sql='''DELETE FROM Inventory(Item,Quantity) VALUES(?,?)'''
       ## cur=conn.cursor()
        ##cur.execute(sql, values)
       ## sql = "DELETE FROM Inventory WHERE itemName = ?"
        ##conn.execute(sql, (itemName,))
        ##conn.commit()
       ## conn.close()
       


        sql='''DELETE FROM Inventory(Item,Quantity) WHERE VALUES(?,?)'''
        cur=conn.cursor()
        values=(0,0)
        cur.execute(sql, values)
        conn.commit()
        conn.close()
