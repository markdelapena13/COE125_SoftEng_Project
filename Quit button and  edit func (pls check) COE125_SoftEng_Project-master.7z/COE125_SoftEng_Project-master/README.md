A simple inventory project for the Software Engineering subject, course code COE125.
You will be greeted with a Login page upon opening the program.
You can sign-in if you already have an existing account and see your inventory.
If you haven't created any account yet then there is a sign-up option to create a new account to start using the inventory management software.
The main purpose of the program is keeping track of anything that you have. This works especially for businesses that wants to track
and keep count of different kind of objects in their inventory
